# Veterinaria PetCare — Sistema de Gestión Médica e Inventario

Proyecto Corte 3 · Programación en Java · UTS (puntos 4 a 11).

**Stack:** Spring Boot 3.3 · Spring Security + JWT (cookie HttpOnly) · Spring Data JPA · MySQL 8 · Thymeleaf · Bootstrap 4.6 · OpenPDF · Java 17.

## Cómo ejecutarlo
1. En MySQL ejecute, en orden: `database/01_veterinaria_petcare_v2.sql` y `database/02_claves_demo.sql`.
2. Ajuste usuario/clave de MySQL en `src/main/resources/application.properties`.
3. En Spring Tools: *Import → Existing Maven Project* y luego *Run As → Spring Boot App* (o `mvn spring-boot:run`).
4. Abra http://localhost:8080 — todos los usuarios de prueba tienen la clave `Petcare2026*`.


| Usuario | Rol | Qué ve |
|---|---|---|
| `admin` | ADMINISTRADOR | Inicio, Mantenimiento, Reportes, Configuración, Contraseña, Salir |
| `recep1` | RECEPCIONISTA | Propietarios, Pacientes, Citas |
| `vet_ana` / `vet_mateo` | VETERINARIO | Historial clínico, Nueva consulta |
| `maria.f` / `juan.t` | CLIENTE | Mis mascotas, Mis citas, Historial (solo lectura) |

## Cumplimiento del PDF del proyecto
| Punto | Dónde está |
|---|---|
| 4. Spring Boot + Thymeleaf | `pom.xml`, `templates/` |
| 5. Login y perfiles | `security/`, `AuthController`, 4 roles |
| 6. Menú del administrador | `templates/fragments/layout.html` |
| · Mantenimiento (CRUD) | `Propietario/Mascota/Veterinario/ProductoController` |
| · Reportes (PDF) | `ReporteController`, `ReporteService` |
| · Configuración (usuarios y grupos) | `ConfigController` |
| · Salir con despedida | `POST /salir` → `despedida.html` |
| 7. Plantilla con logo, usuario, fecha y hora | fragmento `navbar` + `static/img/logo.svg` |
| 8. Cambio de contraseña | `InicioController` → `/contrasena` |
| 9. Menú del usuario operativo | `sec:authorize` por rol en el `navbar` |
| 10. Parte operativa | citas (cliente→recepción) y consulta médica con descuento de stock (`ConsultaService`) |
