package com.petcare.controller;

import com.petcare.model.Mascota;
import com.petcare.service.MascotaService;
import com.petcare.service.PropietarioService;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/mantenimiento/mascotas")
public class MascotaController {

    private final MascotaService service;
    private final PropietarioService propietarioService;

    public MascotaController(MascotaService service, PropietarioService propietarioService) {
        this.service = service;
        this.propietarioService = propietarioService;
    }

    @GetMapping
    public String listar(@RequestParam(required = false) String q, Authentication auth, Model model) {
        boolean admin = auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMINISTRADOR"));
        model.addAttribute("lista", admin ? service.listarTodas(q) : service.listar(q));
        model.addAttribute("q", q);
        return "mantenimiento/mascotas";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("mascota", new Mascota());
        model.addAttribute("propietarios", propietarioService.listar(null));
        return "mantenimiento/mascota-form";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        model.addAttribute("mascota", service.obtener(id));
        model.addAttribute("propietarios", propietarioService.listar(null));
        return "mantenimiento/mascota-form";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("mascota") Mascota m, BindingResult br, Model model, RedirectAttributes ra) {
        if (br.hasErrors()) {
            model.addAttribute("propietarios", propietarioService.listar(null));
            return "mantenimiento/mascota-form";
        }
        service.guardar(m);
        ra.addFlashAttribute("ok", "Mascota guardada correctamente.");
        return "redirect:/mantenimiento/mascotas";
    }

    @PostMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra) {
        service.eliminar(id);
        ra.addFlashAttribute("ok", "Mascota eliminada (oculta). Se borraron sus citas y se conservó su historial médico.");
        return "redirect:/mantenimiento/mascotas";
    }

    @PostMapping("/reactivar/{id}")
    public String reactivar(@PathVariable Long id, RedirectAttributes ra) {
        service.reactivar(id);
        ra.addFlashAttribute("ok", "Mascota reactivada. Vuelve a estar visible junto con su historial.");
        return "redirect:/mantenimiento/mascotas";
    }
}
