package com.petcare.controller;

import com.petcare.model.Rol;
import com.petcare.model.Veterinario;
import com.petcare.service.UsuarioService;
import com.petcare.service.VeterinarioService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/mantenimiento/veterinarios")
public class VeterinarioController {

    private final VeterinarioService service;
    private final UsuarioService usuarioService;

    public VeterinarioController(VeterinarioService service, UsuarioService usuarioService) {
        this.service = service;
        this.usuarioService = usuarioService;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("lista", service.listar());
        return "mantenimiento/veterinarios";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("veterinario", new Veterinario());
        model.addAttribute("usuarios", usuarioService.porRol(Rol.VETERINARIO));
        return "mantenimiento/veterinario-form";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        model.addAttribute("veterinario", service.obtener(id));
        model.addAttribute("usuarios", usuarioService.porRol(Rol.VETERINARIO));
        return "mantenimiento/veterinario-form";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("veterinario") Veterinario v, BindingResult br, Model model, RedirectAttributes ra) {
        if (br.hasErrors()) {
            model.addAttribute("usuarios", usuarioService.porRol(Rol.VETERINARIO));
            return "mantenimiento/veterinario-form";
        }
        service.guardar(v);
        ra.addFlashAttribute("ok", "Veterinario guardado correctamente.");
        return "redirect:/mantenimiento/veterinarios";
    }

    @PostMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra) {
        service.eliminar(id);
        ra.addFlashAttribute("ok", "Veterinario eliminado.");
        return "redirect:/mantenimiento/veterinarios";
    }
}
