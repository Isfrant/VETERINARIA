package com.petcare.repository;

import com.petcare.model.Propietario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;

public interface PropietarioRepository extends JpaRepository<Propietario, Long> {
    Optional<Propietario> findByUsuarioNombreUsuario(String nombreUsuario);
    Optional<Propietario> findByDocumento(String documento);

    @Query("select p from Propietario p where lower(p.nombre) like lower(concat('%', :q, '%')) or p.documento like concat('%', :q, '%') order by p.nombre")
    List<Propietario> buscar(@Param("q") String q);
}
