package com.petcare.controller;

import com.petcare.exception.NegocioException;
import com.petcare.model.Mascota;
import com.petcare.model.Propietario;
import com.petcare.repository.PropietarioRepository;
import com.petcare.service.CitaService;
import com.petcare.service.ConsultaService;
import com.petcare.service.MascotaService;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.time.LocalDate;
import java.time.LocalTime;

@Controller
@RequestMapping("/cliente")
public class ClienteController {

    private final PropietarioRepository propietarioRepo;
    private final MascotaService mascotaService;
    private final CitaService citaService;
    private final ConsultaService consultaService;

    public ClienteController(PropietarioRepository propietarioRepo, MascotaService mascotaService, CitaService citaService, ConsultaService consultaService) {
        this.propietarioRepo = propietarioRepo;
        this.mascotaService = mascotaService;
        this.citaService = citaService;
        this.consultaService = consultaService;
    }

    private Propietario propietario(Authentication auth) {
        return propietarioRepo.findByUsuarioNombreUsuario(auth.getName())
                .orElseThrow(() -> new NegocioException("Su cuenta no está vinculada a un propietario."));
    }

    @GetMapping("/mascotas")
    public String mascotas(@RequestParam(required = false) Long editar, Authentication auth, Model model) {
        Propietario p = propietario(auth);
        model.addAttribute("lista", mascotaService.porPropietario(p));
        Mascota m = new Mascota();
        if (editar != null) {
            m = mascotaService.obtener(editar);
            if (!m.getPropietario().getId().equals(p.getId()) || !Boolean.TRUE.equals(m.getActivo()))
                throw new NegocioException("Esa mascota no es suya.");
        }
        model.addAttribute("mascota", m);
        return "cliente/mascotas";
    }

    @PostMapping("/mascotas/guardar")
    public String guardarMascota(@Valid @ModelAttribute("mascota") Mascota m, BindingResult br,
                                 Authentication auth, Model model, RedirectAttributes ra) {
        Propietario p = propietario(auth);
        if (br.hasErrors()) {
            model.addAttribute("lista", mascotaService.porPropietario(p));
            return "cliente/mascotas";
        }
        mascotaService.guardarDeCliente(m, p);
        ra.addFlashAttribute("ok", "Mascota guardada correctamente.");
        return "redirect:/cliente/mascotas";
    }

    @PostMapping("/mascotas/eliminar/{id}")
    public String eliminarMascota(@PathVariable Long id, Authentication auth, RedirectAttributes ra) {
        mascotaService.eliminarDeCliente(id, propietario(auth));
        ra.addFlashAttribute("ok", "Mascota eliminada.");
        return "redirect:/cliente/mascotas";
    }

    @GetMapping("/citas")
    public String citas(Authentication auth, Model model) {
        Propietario p = propietario(auth);
        model.addAttribute("lista", citaService.deCliente(p));
        model.addAttribute("mascotas", mascotaService.porPropietario(p));
        model.addAttribute("horas", citaService.horasLaborales());
        model.addAttribute("hoy", LocalDate.now().toString());
        return "cliente/citas";
    }

    @PostMapping("/citas/solicitar")
    public String solicitar(@RequestParam Long mascotaId,
                            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha,
                            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime hora,
                            @RequestParam String motivo, Authentication auth, RedirectAttributes ra) {
        citaService.solicitar(auth.getName(), mascotaId, fecha, hora, motivo);
        ra.addFlashAttribute("ok", "Solicitud enviada. Recepción la revisará y recibirá una notificación.");
        return "redirect:/cliente/citas";
    }

    @PostMapping("/citas/cancelar/{id}")
    public String cancelar(@PathVariable Long id, Authentication auth, RedirectAttributes ra) {
        citaService.cancelar(id, auth.getName());
        ra.addFlashAttribute("ok", "Cita cancelada.");
        return "redirect:/cliente/citas";
    }

    @GetMapping("/historial")
    public String historial(Authentication auth, Model model) {
        model.addAttribute("lista", consultaService.deCliente(propietario(auth)));
        return "cliente/historial";
    }
}
