package com.petcare.service;

import com.petcare.exception.NegocioException;
import com.petcare.model.Propietario;
import com.petcare.repository.PropietarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class PropietarioService {

    private final PropietarioRepository repo;

    public PropietarioService(PropietarioRepository repo) {
        this.repo = repo;
    }

    public List<Propietario> listar(String q) {
        return (q == null || q.isBlank()) ? repo.findAll() : repo.buscar(q.trim());
    }

    public Propietario obtener(Long id) {
        return repo.findById(id).orElseThrow(() -> new NegocioException("El propietario no existe."));
    }

    @Transactional
    public Propietario guardar(Propietario form) {
        repo.findByDocumento(form.getDocumento()).ifPresent(existente -> {
            if (!existente.getId().equals(form.getId())) {
                throw new NegocioException("Ya existe un propietario con ese documento.");
            }
        });
        Propietario p = (form.getId() == null) ? new Propietario() : obtener(form.getId());
        p.setDocumento(form.getDocumento());
        p.setNombre(form.getNombre());
        p.setTelefono(form.getTelefono());
        p.setEmail(form.getEmail());
        return repo.save(p);
    }

    @Transactional
    public void eliminar(Long id) {
        repo.deleteById(id);
        repo.flush();
    }
}
