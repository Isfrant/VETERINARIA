package com.petcare.controller;

import com.petcare.exception.NegocioException;
import com.petcare.model.Propietario;
import com.petcare.service.PropietarioService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/mantenimiento/propietarios")
public class PropietarioController {

    private final PropietarioService service;

    public PropietarioController(PropietarioService service) {
        this.service = service;
    }

    @GetMapping
    public String listar(@RequestParam(required = false) String q, Model model) {
        model.addAttribute("lista", service.listar(q));
        model.addAttribute("q", q);
        return "mantenimiento/propietarios";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("propietario", new Propietario());
        return "mantenimiento/propietario-form";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        model.addAttribute("propietario", service.obtener(id));
        return "mantenimiento/propietario-form";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("propietario") Propietario p, BindingResult br, RedirectAttributes ra) {
        if (br.hasErrors()) return "mantenimiento/propietario-form";
        try {
            service.guardar(p);
        } catch (NegocioException e) {
            br.rejectValue("documento", "duplicado", e.getMessage());
            return "mantenimiento/propietario-form";
        }
        ra.addFlashAttribute("ok", "Propietario guardado correctamente.");
        return "redirect:/mantenimiento/propietarios";
    }

    @PostMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra) {
        service.eliminar(id);
        ra.addFlashAttribute("ok", "Propietario eliminado.");
        return "redirect:/mantenimiento/propietarios";
    }
}
