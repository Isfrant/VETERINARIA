package com.petcare.repository;

import com.petcare.model.HistorialClinico;
import com.petcare.model.Mascota;
import com.petcare.model.Propietario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface HistorialRepository extends JpaRepository<HistorialClinico, Long> {
    @Query("select h from HistorialClinico h where h.mascota.activo = true order by h.fecha desc, h.id desc")
    List<HistorialClinico> findVisibles();

    @Query("select h from HistorialClinico h where h.mascota.propietario = :p and h.mascota.activo = true order by h.fecha desc, h.id desc")
    List<HistorialClinico> visibleDePropietario(@Param("p") Propietario p);

    List<HistorialClinico> findAllByOrderByFechaDescIdDesc();
    List<HistorialClinico> findByMascotaOrderByFechaDescIdDesc(Mascota mascota);
    List<HistorialClinico> findByMascotaPropietarioOrderByFechaDescIdDesc(Propietario propietario);
}
