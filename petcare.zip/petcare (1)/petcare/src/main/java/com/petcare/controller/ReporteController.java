package com.petcare.controller;

import com.petcare.service.MascotaService;
import com.petcare.service.ReporteService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/reportes")
public class ReporteController {

    private final ReporteService reportes;
    private final MascotaService mascotaService;

    public ReporteController(ReporteService reportes, MascotaService mascotaService) {
        this.reportes = reportes;
        this.mascotaService = mascotaService;
    }

    @GetMapping
    public String indice(Model model) {
        model.addAttribute("mascotas", mascotaService.listarTodas(null));
        return "reportes/index";
    }

    @GetMapping("/inventario")
    public ResponseEntity<byte[]> inventario() { return pdf(reportes.inventario(), "inventario"); }

    @GetMapping("/stock-bajo")
    public ResponseEntity<byte[]> stockBajo() { return pdf(reportes.stockBajo(), "stock-bajo"); }

    @GetMapping("/consumo")
    public ResponseEntity<byte[]> consumo() { return pdf(reportes.consumoMensual(), "consumo-mensual"); }

    @GetMapping("/citas")
    public ResponseEntity<byte[]> citas() { return pdf(reportes.citas(), "citas"); }

    @GetMapping("/pacientes")
    public ResponseEntity<byte[]> pacientes() { return pdf(reportes.pacientes(), "pacientes"); }

    @GetMapping("/historial")
    public ResponseEntity<byte[]> historial(@RequestParam Long mascotaId) {
        return pdf(reportes.historial(mascotaId), "historial-clinico");
    }

    private ResponseEntity<byte[]> pdf(byte[] contenido, String nombre) {
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=" + nombre + ".pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(contenido);
    }
}
