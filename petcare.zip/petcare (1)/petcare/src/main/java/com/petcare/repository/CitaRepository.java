package com.petcare.repository;

import com.petcare.model.Cita;
import com.petcare.model.EstadoCita;
import com.petcare.model.Propietario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Collection;
import java.util.List;

public interface CitaRepository extends JpaRepository<Cita, Long> {
    List<Cita> findAllByOrderByFechaDescHoraDesc();
    List<Cita> findByEstadoOrderByFechaAscHoraAsc(EstadoCita estado);
    List<Cita> findByPropietarioOrderByFechaDescHoraDesc(Propietario propietario);
    boolean existsByFechaAndHoraAndEstadoIn(LocalDate fecha, LocalTime hora, Collection<EstadoCita> estados);
    List<Cita> findByEstadoInOrderByFechaAscHoraAsc(Collection<EstadoCita> estados);
    void deleteByMascota(com.petcare.model.Mascota mascota);
    long countByEstado(EstadoCita estado);
}
