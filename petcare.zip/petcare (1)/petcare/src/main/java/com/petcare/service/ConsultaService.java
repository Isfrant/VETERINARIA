package com.petcare.service;

import com.petcare.exception.NegocioException;
import com.petcare.model.*;
import com.petcare.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.List;

@Service
public class ConsultaService {

    private final HistorialRepository historialRepo;
    private final MascotaRepository mascotaRepo;
    private final VeterinarioRepository veterinarioRepo;
    private final ProductoRepository productoRepo;
    private final CitaRepository citaRepo;

    public ConsultaService(HistorialRepository historialRepo, MascotaRepository mascotaRepo, VeterinarioRepository veterinarioRepo, ProductoRepository productoRepo, CitaRepository citaRepo) {
        this.historialRepo = historialRepo;
        this.mascotaRepo = mascotaRepo;
        this.veterinarioRepo = veterinarioRepo;
        this.productoRepo = productoRepo;
        this.citaRepo = citaRepo;
    }

    public List<HistorialClinico> listar(Long mascotaId) {
        if (mascotaId == null) return historialRepo.findVisibles();
        return historialRepo.findByMascotaOrderByFechaDescIdDesc(
                mascotaRepo.findById(mascotaId).orElseThrow(() -> new NegocioException("La mascota no existe.")));
    }

    public HistorialClinico obtener(Long id) {
        return historialRepo.findById(id).orElseThrow(() -> new NegocioException("La consulta no existe."));
    }

    public List<HistorialClinico> deCliente(Propietario p) {
        return historialRepo.visibleDePropietario(p);
    }

    @Transactional
    public HistorialClinico registrar(String username, Long mascotaId, Long citaId, String motivo,
                                      String diagnostico, String tratamiento,
                                      List<Long> productoIds, List<Integer> cantidades) {
        Veterinario vet = veterinarioRepo.findByUsuarioNombreUsuario(username)
                .orElseThrow(() -> new NegocioException(
                        "Su usuario no está vinculado a un veterinario. Pida al administrador que lo vincule."));
        Mascota mascota = mascotaRepo.findById(mascotaId)
                .orElseThrow(() -> new NegocioException("Seleccione una mascota válida."));
        if (!Boolean.TRUE.equals(mascota.getActivo())) throw new NegocioException("La mascota está inactiva (eliminada).");
        if (motivo == null || motivo.isBlank()) throw new NegocioException("El motivo es obligatorio.");

        HistorialClinico h = new HistorialClinico();
        h.setFecha(LocalDate.now());
        h.setMotivo(motivo.trim());
        h.setDiagnostico(diagnostico);
        h.setTratamiento(tratamiento);
        h.setMascota(mascota);
        h.setVeterinario(vet);

        if (citaId != null) {
            Cita cita = citaRepo.findById(citaId).orElseThrow(() -> new NegocioException("La cita no existe."));
            if (!cita.getMascota().getId().equals(mascota.getId()))
                throw new NegocioException("La cita seleccionada pertenece a otra mascota (" + cita.getMascota().getNombre() + ").");
            if (cita.getEstado() != EstadoCita.APROBADA && cita.getEstado() != EstadoCita.REPROGRAMADA)
                throw new NegocioException("La cita no está aprobada para ser atendida.");
            cita.setEstado(EstadoCita.ATENDIDA);
            h.setCita(cita);
        }

        if (productoIds != null) {
            for (int i = 0; i < productoIds.size(); i++) {
                Long pid = productoIds.get(i);
                Integer cant = (cantidades != null && i < cantidades.size()) ? cantidades.get(i) : null;
                if (pid == null || cant == null) continue;
                if (cant <= 0) throw new NegocioException("La cantidad debe ser mayor a cero.");

                Producto prod = productoRepo.buscarParaActualizar(pid)
                        .orElseThrow(() -> new NegocioException("El producto no existe."));
                if (!Boolean.TRUE.equals(prod.getActivo()))
                    throw new NegocioException("El producto '" + prod.getNombre() + "' está inactivo.");
                if (prod.getStockActual() < cant)
                    throw new NegocioException("Stock insuficiente de '" + prod.getNombre()
                            + "': disponible " + prod.getStockActual() + ", solicitado " + cant + ".");

                prod.setStockActual(prod.getStockActual() - cant);
                DetalleAtencion d = new DetalleAtencion();
                d.setHistorial(h);
                d.setProducto(prod);
                d.setCantidadUtilizada(cant);
                h.getDetalles().add(d);
            }
        }
        return historialRepo.save(h);
    }
}
