package com.petcare.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
public class Cita {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false) private LocalDate fecha;
    @Column(nullable = false) private LocalTime hora;
    @Column(nullable = false) private String motivo;
    @Enumerated(EnumType.STRING) @Column(nullable = false)
    private EstadoCita estado = EstadoCita.PENDIENTE;
    @ManyToOne(optional = false) @JoinColumn(name = "propietario_id")
    private Propietario propietario;
    @ManyToOne(optional = false) @JoinColumn(name = "mascota_id")
    private Mascota mascota;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }

    public LocalTime getHora() { return hora; }
    public void setHora(LocalTime hora) { this.hora = hora; }

    public String getMotivo() { return motivo; }
    public void setMotivo(String motivo) { this.motivo = motivo; }

    public EstadoCita getEstado() { return estado; }
    public void setEstado(EstadoCita estado) { this.estado = estado; }

    public Propietario getPropietario() { return propietario; }
    public void setPropietario(Propietario propietario) { this.propietario = propietario; }

    public Mascota getMascota() { return mascota; }
    public void setMascota(Mascota mascota) { this.mascota = mascota; }
}
