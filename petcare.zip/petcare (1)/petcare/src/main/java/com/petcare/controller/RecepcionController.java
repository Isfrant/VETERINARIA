package com.petcare.controller;

import com.petcare.model.EstadoCita;
import com.petcare.service.CitaService;
import com.petcare.service.MascotaService;
import com.petcare.service.PropietarioService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.time.LocalDate;
import java.time.LocalTime;

@Controller
@RequestMapping("/recepcion/citas")
public class RecepcionController {

    private final CitaService citaService;
    private final PropietarioService propietarioService;
    private final MascotaService mascotaService;

    public RecepcionController(CitaService citaService, PropietarioService propietarioService, MascotaService mascotaService) {
        this.citaService = citaService;
        this.propietarioService = propietarioService;
        this.mascotaService = mascotaService;
    }

    @GetMapping
    public String listar(@RequestParam(required = false) EstadoCita estado, Model model) {
        model.addAttribute("lista", citaService.listar(estado));
        model.addAttribute("estados", EstadoCita.values());
        model.addAttribute("estadoSel", estado);
        model.addAttribute("horas", citaService.horasLaborales());
        model.addAttribute("propietarios", propietarioService.listar(null));
        model.addAttribute("mascotas", mascotaService.listar(null));
        model.addAttribute("hoy", LocalDate.now().toString());
        return "recepcion/citas";
    }

    @PostMapping("/crear")
    public String crear(@RequestParam Long propietarioId,
                        @RequestParam Long mascotaId,
                        @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha,
                        @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime hora,
                        @RequestParam String motivo,
                        RedirectAttributes ra) {
        citaService.crearPorRecepcion(propietarioId, mascotaId, fecha, hora, motivo);
        ra.addFlashAttribute("ok", "Cita programada y aprobada correctamente.");
        return "redirect:/recepcion/citas";
    }

    @PostMapping("/aprobar/{id}")
    public String aprobar(@PathVariable Long id, RedirectAttributes ra) {
        citaService.aprobar(id);
        ra.addFlashAttribute("ok", "Cita aprobada. Se notificó al cliente.");
        return "redirect:/recepcion/citas";
    }

    @PostMapping("/rechazar/{id}")
    public String rechazar(@PathVariable Long id, RedirectAttributes ra) {
        citaService.rechazar(id);
        ra.addFlashAttribute("ok", "Cita rechazada. Se notificó al cliente.");
        return "redirect:/recepcion/citas";
    }

    @PostMapping("/reprogramar/{id}")
    public String reprogramar(@PathVariable Long id,
                              @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha,
                              @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime hora,
                              RedirectAttributes ra) {
        citaService.reprogramar(id, fecha, hora);
        ra.addFlashAttribute("ok", "Cita reprogramada. Se notificó al cliente.");
        return "redirect:/recepcion/citas";
    }
}
