package com.petcare.dto;

import com.petcare.model.Rol;
import jakarta.validation.constraints.*;

public class UsuarioForm {
    private Long id;
    @NotBlank(message = "El usuario es obligatorio") @Size(min = 4, max = 50, message = "Entre 4 y 50 caracteres")
    private String nombreUsuario;
    private String contrasena;
    @NotNull(message = "Seleccione un rol")
    private Rol rol;
    private Boolean estado = true;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombreUsuario() { return nombreUsuario; }
    public void setNombreUsuario(String nombreUsuario) { this.nombreUsuario = nombreUsuario; }

    public String getContrasena() { return contrasena; }
    public void setContrasena(String contrasena) { this.contrasena = contrasena; }

    public Rol getRol() { return rol; }
    public void setRol(Rol rol) { this.rol = rol; }

    public Boolean getEstado() { return estado; }
    public void setEstado(Boolean estado) { this.estado = estado; }
}
