package com.petcare.service;

import com.petcare.exception.NegocioException;
import com.petcare.model.Veterinario;
import com.petcare.repository.UsuarioRepository;
import com.petcare.repository.VeterinarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class VeterinarioService {

    private final VeterinarioRepository repo;
    private final UsuarioRepository usuarioRepo;

    public VeterinarioService(VeterinarioRepository repo, UsuarioRepository usuarioRepo) {
        this.repo = repo;
        this.usuarioRepo = usuarioRepo;
    }

    public List<Veterinario> listar() {
        return repo.findAll();
    }

    public Veterinario obtener(Long id) {
        return repo.findById(id).orElseThrow(() -> new NegocioException("El veterinario no existe."));
    }

    @Transactional
    public Veterinario guardar(Veterinario form) {
        Veterinario v = (form.getId() == null) ? new Veterinario() : obtener(form.getId());
        v.setDocumento(form.getDocumento());
        v.setNombre(form.getNombre());
        v.setTelefono(form.getTelefono());
        v.setEmail(form.getEmail());
        if (form.getUsuario() != null && form.getUsuario().getId() != null) {
            v.setUsuario(usuarioRepo.findById(form.getUsuario().getId())
                    .orElseThrow(() -> new NegocioException("El usuario seleccionado no existe.")));
        } else {
            v.setUsuario(null);
        }
        return repo.save(v);
    }

    @Transactional
    public void eliminar(Long id) {
        repo.deleteById(id);
        repo.flush();
    }
}
