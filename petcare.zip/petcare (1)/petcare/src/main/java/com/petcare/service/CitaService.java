package com.petcare.service;

import com.petcare.exception.NegocioException;
import com.petcare.model.*;
import com.petcare.repository.CitaRepository;
import com.petcare.repository.MascotaRepository;
import com.petcare.repository.NotificacionRepository;
import com.petcare.repository.PropietarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
public class CitaService {

    private static final List<EstadoCita> ACTIVAS =
            List.of(EstadoCita.PENDIENTE, EstadoCita.APROBADA, EstadoCita.REPROGRAMADA);
    private static final LocalTime APERTURA = LocalTime.of(8, 0);
    private static final LocalTime CIERRE = LocalTime.of(17, 0);
    private static final DateTimeFormatter FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final CitaRepository repo;
    private final MascotaRepository mascotaRepo;
    private final PropietarioRepository propietarioRepo;
    private final NotificacionRepository notificacionRepo;

    public CitaService(CitaRepository repo, MascotaRepository mascotaRepo, PropietarioRepository propietarioRepo, NotificacionRepository notificacionRepo) {
        this.repo = repo;
        this.mascotaRepo = mascotaRepo;
        this.propietarioRepo = propietarioRepo;
        this.notificacionRepo = notificacionRepo;
    }

    public List<String> horasLaborales() {
        List<String> horas = new ArrayList<>();
        for (LocalTime t = APERTURA; !t.isAfter(CIERRE); t = t.plusMinutes(30)) horas.add(t.toString());
        return horas;
    }

    public List<Cita> listar(EstadoCita estado) {
        return (estado == null) ? repo.findAllByOrderByFechaDescHoraDesc()
                                : repo.findByEstadoOrderByFechaAscHoraAsc(estado);
    }

    public List<Cita> paraAtender() {
        return repo.findByEstadoInOrderByFechaAscHoraAsc(List.of(EstadoCita.APROBADA, EstadoCita.REPROGRAMADA));
    }

    public List<Cita> deCliente(Propietario p) {
        return repo.findByPropietarioOrderByFechaDescHoraDesc(p);
    }

    @Transactional
    public Cita solicitar(String username, Long mascotaId, LocalDate fecha, LocalTime hora, String motivo) {
        Propietario p = propietarioRepo.findByUsuarioNombreUsuario(username)
                .orElseThrow(() -> new NegocioException("Su cuenta no está vinculada a un propietario."));
        Mascota m = mascotaRepo.findById(mascotaId)
                .filter(x -> x.getPropietario().getId().equals(p.getId()) && Boolean.TRUE.equals(x.getActivo()))
                .orElseThrow(() -> new NegocioException("La mascota no pertenece a su cuenta."));
        if (motivo == null || motivo.isBlank()) throw new NegocioException("Indique el motivo de la consulta.");
        validarHorario(fecha, hora);

        Cita c = new Cita();
        c.setPropietario(p);
        c.setMascota(m);
        c.setFecha(fecha);
        c.setHora(hora);
        c.setMotivo(motivo.trim());
        c.setEstado(EstadoCita.PENDIENTE);
        return repo.save(c);
    }

    @Transactional
    public Cita crearPorRecepcion(Long propietarioId, Long mascotaId, LocalDate fecha, LocalTime hora, String motivo) {
        Propietario p = propietarioRepo.findById(propietarioId)
                .orElseThrow(() -> new NegocioException("Seleccione un propietario válido."));
        Mascota m = mascotaRepo.findById(mascotaId)
                .filter(x -> x.getPropietario().getId().equals(p.getId()) && Boolean.TRUE.equals(x.getActivo()))
                .orElseThrow(() -> new NegocioException("La mascota no pertenece a ese propietario."));
        if (motivo == null || motivo.isBlank()) throw new NegocioException("Indique el motivo de la consulta.");
        validarHorario(fecha, hora);

        Cita c = new Cita();
        c.setPropietario(p);
        c.setMascota(m);
        c.setFecha(fecha);
        c.setHora(hora);
        c.setMotivo(motivo.trim());
        c.setEstado(EstadoCita.APROBADA);
        repo.save(c);
        notificar(c, TipoNotificacion.CITA_APROBADA, "Se programó una cita para " + m.getNombre()
                + " el " + fecha.format(FECHA) + " a las " + hora + ".");
        return c;
    }

    @Transactional
    public void aprobar(Long id) {
        Cita c = obtenerPendiente(id);
        c.setEstado(EstadoCita.APROBADA);
        notificar(c, TipoNotificacion.CITA_APROBADA, "Su cita para " + c.getMascota().getNombre()
                + " el " + c.getFecha().format(FECHA) + " a las " + c.getHora() + " fue aprobada.");
    }

    @Transactional
    public void rechazar(Long id) {
        Cita c = obtenerPendiente(id);
        c.setEstado(EstadoCita.RECHAZADA);
        notificar(c, TipoNotificacion.CITA_RECHAZADA, "Su solicitud de cita para " + c.getMascota().getNombre()
                + " del " + c.getFecha().format(FECHA) + " fue rechazada. Puede solicitar otro horario.");
    }

    @Transactional
    public void reprogramar(Long id, LocalDate fecha, LocalTime hora) {
        Cita c = obtener(id);
        if (!ACTIVAS.contains(c.getEstado())) throw new NegocioException("Solo se pueden reprogramar citas activas.");
        validarHorario(fecha, hora);
        c.setFecha(fecha);
        c.setHora(hora);
        c.setEstado(EstadoCita.REPROGRAMADA);
        notificar(c, TipoNotificacion.CITA_REPROGRAMADA, "Su cita para " + c.getMascota().getNombre()
                + " fue reprogramada al " + fecha.format(FECHA) + " a las " + hora + ".");
    }

    @Transactional
    public void cancelar(Long id, String username) {
        Cita c = obtener(id);
        if (c.getPropietario().getUsuario() == null
                || !c.getPropietario().getUsuario().getNombreUsuario().equals(username)) {
            throw new NegocioException("Esa cita no pertenece a su cuenta.");
        }
        if (!ACTIVAS.contains(c.getEstado())) throw new NegocioException("Esa cita ya no se puede cancelar.");
        c.setEstado(EstadoCita.CANCELADA);
    }

    private Cita obtener(Long id) {
        return repo.findById(id).orElseThrow(() -> new NegocioException("La cita no existe."));
    }

    private Cita obtenerPendiente(Long id) {
        Cita c = obtener(id);
        if (c.getEstado() != EstadoCita.PENDIENTE) throw new NegocioException("La cita ya fue gestionada.");
        return c;
    }

    private void validarHorario(LocalDate fecha, LocalTime hora) {
        if (fecha == null || hora == null) throw new NegocioException("Seleccione fecha y hora.");
        if (fecha.isBefore(LocalDate.now())) throw new NegocioException("La fecha no puede ser anterior a hoy.");
        if (hora.isBefore(APERTURA) || hora.isAfter(CIERRE))
            throw new NegocioException("El horario de atención es de 08:00 a 17:00.");
        if (repo.existsByFechaAndHoraAndEstadoIn(fecha, hora, ACTIVAS))
            throw new NegocioException("Ese horario ya está ocupado. Elija otro.");
    }

    private void notificar(Cita c, TipoNotificacion tipo, String mensaje) {
        Usuario destino = c.getPropietario().getUsuario();
        if (destino == null) return;
        Notificacion n = new Notificacion();
        n.setUsuario(destino);
        n.setTipo(tipo);
        n.setMensaje(mensaje);
        n.setCita(c);
        notificacionRepo.save(n);
    }
}
