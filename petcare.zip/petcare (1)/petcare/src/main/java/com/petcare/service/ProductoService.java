package com.petcare.service;

import com.petcare.exception.NegocioException;
import com.petcare.model.Producto;
import com.petcare.repository.ProductoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class ProductoService {

    private final ProductoRepository repo;

    public ProductoService(ProductoRepository repo) {
        this.repo = repo;
    }

    public List<Producto> listar() {
        return repo.findAllByOrderByNombre();
    }

    public List<Producto> activos() {
        return repo.findByActivoTrueOrderByNombre();
    }

    public Producto obtener(Long id) {
        return repo.findById(id).orElseThrow(() -> new NegocioException("El producto no existe."));
    }

    @Transactional
    public Producto guardar(Producto p) {
        return repo.save(p);
    }

    @Transactional
    public void eliminar(Long id) {
        repo.deleteById(id);
        repo.flush();
    }
}
