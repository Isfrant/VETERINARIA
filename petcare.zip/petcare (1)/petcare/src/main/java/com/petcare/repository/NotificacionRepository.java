package com.petcare.repository;

import com.petcare.model.Notificacion;
import com.petcare.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface NotificacionRepository extends JpaRepository<Notificacion, Long> {
    List<Notificacion> findTop10ByUsuarioOrderByFechaEnvioDesc(Usuario usuario);
}
