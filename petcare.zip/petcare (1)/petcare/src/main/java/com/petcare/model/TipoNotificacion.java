package com.petcare.model;

public enum TipoNotificacion { CITA_APROBADA, CITA_RECHAZADA, CITA_REPROGRAMADA, RECORDATORIO_CITA, STOCK_BAJO }
