package com.petcare.repository;

import com.petcare.model.Mascota;
import com.petcare.model.Propietario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface MascotaRepository extends JpaRepository<Mascota, Long> {
    List<Mascota> findByPropietarioAndActivoTrueOrderByNombre(Propietario propietario);
    List<Mascota> findByActivoTrueOrderByNombre();
    long countByActivoTrue();

    @Query("select m from Mascota m where lower(m.nombre) like lower(concat('%', :q, '%')) "
         + "or m.propietario.documento like concat('%', :q, '%') "
         + "or lower(m.propietario.nombre) like lower(concat('%', :q, '%')) order by m.nombre")
    List<Mascota> buscar(@Param("q") String q);

    @Query("select m from Mascota m where m.activo = true and (lower(m.nombre) like lower(concat('%', :q, '%')) "
         + "or m.propietario.documento like concat('%', :q, '%') "
         + "or lower(m.propietario.nombre) like lower(concat('%', :q, '%'))) order by m.nombre")
    List<Mascota> buscarActivas(@Param("q") String q);
}
