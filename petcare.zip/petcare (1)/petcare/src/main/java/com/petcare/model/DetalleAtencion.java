package com.petcare.model;

import jakarta.persistence.*;

@Entity
public class DetalleAtencion {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(optional = false) @JoinColumn(name = "historial_id")
    private HistorialClinico historial;
    @ManyToOne(optional = false) @JoinColumn(name = "producto_id")
    private Producto producto;
    @Column(nullable = false)
    private Integer cantidadUtilizada;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public HistorialClinico getHistorial() { return historial; }
    public void setHistorial(HistorialClinico historial) { this.historial = historial; }

    public Producto getProducto() { return producto; }
    public void setProducto(Producto producto) { this.producto = producto; }

    public Integer getCantidadUtilizada() { return cantidadUtilizada; }
    public void setCantidadUtilizada(Integer cantidadUtilizada) { this.cantidadUtilizada = cantidadUtilizada; }
}
