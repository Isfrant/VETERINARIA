package com.petcare.controller;

import com.petcare.dto.RegistroForm;
import com.petcare.exception.NegocioException;
import com.petcare.security.JwtAuthFilter;
import com.petcare.security.JwtService;
import com.petcare.service.UsuarioService;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    private final AuthenticationManager authManager;
    private final JwtService jwtService;
    private final UsuarioService usuarioService;

    public AuthController(AuthenticationManager authManager, JwtService jwtService, UsuarioService usuarioService) {
        this.authManager = authManager;
        this.jwtService = jwtService;
        this.usuarioService = usuarioService;
    }

    @Value("${app.jwt.cookie-secure:false}")
    private boolean cookieSecure;

    @GetMapping("/")
    public String raiz() {
        return "redirect:/inicio";
    }

    @GetMapping("/login")
    public String loginForm() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String usuario, @RequestParam String clave, HttpServletResponse resp) {
        try {
            Authentication auth = authManager.authenticate(new UsernamePasswordAuthenticationToken(usuario, clave));
            String rol = auth.getAuthorities().iterator().next().getAuthority().replace("ROLE_", "");
            String token = jwtService.generarToken(auth.getName(), rol);
            resp.addHeader(HttpHeaders.SET_COOKIE, cookie(token, jwtService.getExpirationSeconds()).toString());
            return "redirect:/inicio";
        } catch (AuthenticationException e) {
            return "redirect:/login?error";
        }
    }

    @PostMapping("/salir")
    public String salir(HttpServletResponse resp) {
        resp.addHeader(HttpHeaders.SET_COOKIE, cookie("", 0).toString());
        return "redirect:/despedida";
    }

    @GetMapping("/despedida")
    public String despedida() {
        return "despedida";
    }

    @GetMapping("/acceso-denegado")
    public String denegado() {
        return "acceso-denegado";
    }

    @GetMapping("/registro")
    public String registroForm(Model model) {
        model.addAttribute("form", new RegistroForm());
        return "registro";
    }

    @PostMapping("/registro")
    public String registrar(@Valid @ModelAttribute("form") RegistroForm form, BindingResult br) {
        if (br.hasErrors()) return "registro";
        try {
            usuarioService.registrarCliente(form);
        } catch (NegocioException e) {
            br.reject("negocio", e.getMessage());
            return "registro";
        }
        return "redirect:/login?registrado";
    }

    private ResponseCookie cookie(String valor, long segundos) {
        return ResponseCookie.from(JwtAuthFilter.COOKIE, valor)
                .httpOnly(true).secure(cookieSecure).sameSite("Lax").path("/").maxAge(segundos).build();
    }
}
