package com.petcare.service;

import com.petcare.dto.RegistroForm;
import com.petcare.dto.UsuarioForm;
import com.petcare.exception.NegocioException;
import com.petcare.model.Propietario;
import com.petcare.model.Rol;
import com.petcare.model.Usuario;
import com.petcare.repository.PropietarioRepository;
import com.petcare.repository.UsuarioRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class UsuarioService {

    private final UsuarioRepository repo;
    private final PropietarioRepository propietarioRepo;
    private final PasswordEncoder encoder;

    public UsuarioService(UsuarioRepository repo, PropietarioRepository propietarioRepo, PasswordEncoder encoder) {
        this.repo = repo;
        this.propietarioRepo = propietarioRepo;
        this.encoder = encoder;
    }

    public List<Usuario> listar() {
        return repo.findAll();
    }

    public List<Usuario> porRol(Rol rol) {
        return repo.findByRol(rol);
    }

    public Usuario obtener(Long id) {
        return repo.findById(id).orElseThrow(() -> new NegocioException("El usuario no existe."));
    }

    @Transactional
    public Usuario guardar(UsuarioForm f) {
        Usuario u;
        boolean hayClave = f.getContrasena() != null && !f.getContrasena().isBlank();
        if (f.getId() == null) {
            if (!hayClave) throw new NegocioException("La contraseña es obligatoria al crear un usuario.");
            u = new Usuario();
        } else {
            u = obtener(f.getId());
        }
        Usuario otro = repo.findByNombreUsuario(f.getNombreUsuario()).orElse(null);
        if (otro != null && !otro.getId().equals(u.getId())) {
            throw new NegocioException("El nombre de usuario ya está en uso.");
        }
        if (hayClave) {
            validarClave(f.getContrasena());
            u.setContrasena(encoder.encode(f.getContrasena()));
        }
        u.setNombreUsuario(f.getNombreUsuario());
        u.setRol(f.getRol());
        u.setEstado(f.getEstado() != null && f.getEstado());
        return repo.save(u);
    }

    @Transactional
    public void eliminar(Long id, String usuarioActual) {
        if (obtener(id).getNombreUsuario().equals(usuarioActual)) {
            throw new NegocioException("No puede eliminar su propio usuario.");
        }
        repo.deleteById(id);
        repo.flush();
    }

    @Transactional
    public void registrarCliente(RegistroForm f) {
        if (repo.existsByNombreUsuario(f.getNombreUsuario())) {
            throw new NegocioException("El nombre de usuario ya está en uso.");
        }
        Propietario p = propietarioRepo.findByDocumento(f.getDocumento()).orElse(null);
        if (p != null && p.getUsuario() != null) {
            throw new NegocioException("Ese documento ya tiene una cuenta registrada.");
        }
        Usuario u = new Usuario();
        u.setNombreUsuario(f.getNombreUsuario());
        u.setContrasena(encoder.encode(f.getContrasena()));
        u.setRol(Rol.CLIENTE);
        u.setEstado(true);
        repo.save(u);

        if (p == null) {
            p = new Propietario();
            p.setDocumento(f.getDocumento());
            p.setNombre(f.getNombre());
            p.setTelefono(f.getTelefono());
            p.setEmail(f.getEmail());
        }
        p.setUsuario(u);
        propietarioRepo.save(p);
    }

    @Transactional
    public void cambiarClave(String username, String actual, String nueva, String confirmacion) {
        Usuario u = repo.findByNombreUsuario(username).orElseThrow(() -> new NegocioException("Usuario no encontrado."));
        if (!encoder.matches(actual, u.getContrasena())) throw new NegocioException("La contraseña actual no es correcta.");
        if (!nueva.equals(confirmacion)) throw new NegocioException("La confirmación no coincide con la nueva contraseña.");
        validarClave(nueva);
        u.setContrasena(encoder.encode(nueva));
        repo.save(u);
    }

    private void validarClave(String clave) {
        if (clave.length() < 6) throw new NegocioException("La contraseña debe tener mínimo 6 caracteres.");
    }
}
