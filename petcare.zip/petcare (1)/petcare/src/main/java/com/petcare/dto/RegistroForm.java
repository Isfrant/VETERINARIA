package com.petcare.dto;

import jakarta.validation.constraints.*;

public class RegistroForm {
    @NotBlank(message = "El documento es obligatorio") @Size(max = 20)
    private String documento;
    @NotBlank(message = "El nombre es obligatorio") @Size(max = 100)
    private String nombre;
    @Size(max = 20)
    private String telefono;
    @Email(message = "Correo no válido")
    private String email;
    @NotBlank(message = "El usuario es obligatorio") @Size(min = 4, max = 50, message = "Entre 4 y 50 caracteres")
    private String nombreUsuario;
    @NotBlank(message = "La contraseña es obligatoria") @Size(min = 6, message = "Mínimo 6 caracteres")
    private String contrasena;

    public String getDocumento() { return documento; }
    public void setDocumento(String documento) { this.documento = documento; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getNombreUsuario() { return nombreUsuario; }
    public void setNombreUsuario(String nombreUsuario) { this.nombreUsuario = nombreUsuario; }

    public String getContrasena() { return contrasena; }
    public void setContrasena(String contrasena) { this.contrasena = contrasena; }
}
