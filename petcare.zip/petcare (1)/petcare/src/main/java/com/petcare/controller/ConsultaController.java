package com.petcare.controller;

import com.petcare.model.EstadoCita;
import com.petcare.service.CitaService;
import com.petcare.service.ConsultaService;
import com.petcare.service.MascotaService;
import com.petcare.service.ProductoService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.List;

@Controller
@RequestMapping("/veterinario/consultas")
public class ConsultaController {

    private final ConsultaService consultaService;
    private final MascotaService mascotaService;
    private final ProductoService productoService;
    private final CitaService citaService;

    public ConsultaController(ConsultaService consultaService, MascotaService mascotaService, ProductoService productoService, CitaService citaService) {
        this.consultaService = consultaService;
        this.mascotaService = mascotaService;
        this.productoService = productoService;
        this.citaService = citaService;
    }

    @GetMapping
    public String listar(@RequestParam(required = false) Long mascotaId, Model model) {
        model.addAttribute("lista", consultaService.listar(mascotaId));
        model.addAttribute("mascotas", mascotaService.listar(null));
        model.addAttribute("mascotaSel", mascotaId);
        return "veterinario/consultas";
    }

    @GetMapping("/nueva")
    public String nueva(@RequestParam(required = false) Long mascotaId, Model model) {
        model.addAttribute("mascotas", mascotaService.listar(null));
        model.addAttribute("productos", productoService.activos());
        model.addAttribute("citas", citaService.paraAtender());
        model.addAttribute("mascotaSel", mascotaId);
        return "veterinario/consulta-form";
    }

    @PostMapping("/guardar")
    public String guardar(@RequestParam Long mascotaId,
                          @RequestParam(required = false) Long citaId,
                          @RequestParam String motivo,
                          @RequestParam(required = false) String diagnostico,
                          @RequestParam(required = false) String tratamiento,
                          @RequestParam(required = false) List<Long> productoId,
                          @RequestParam(required = false) List<Integer> cantidad,
                          Authentication auth, RedirectAttributes ra) {
        consultaService.registrar(auth.getName(), mascotaId, citaId, motivo, diagnostico, tratamiento, productoId, cantidad);
        ra.addFlashAttribute("ok", "Consulta registrada y stock actualizado.");
        return "redirect:/veterinario/consultas";
    }

    @GetMapping("/{id}")
    public String detalle(@PathVariable Long id, Model model) {
        model.addAttribute("h", consultaService.obtener(id));
        return "veterinario/consulta-detalle";
    }
}
