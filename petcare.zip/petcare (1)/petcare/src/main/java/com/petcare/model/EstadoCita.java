package com.petcare.model;

public enum EstadoCita { PENDIENTE, APROBADA, RECHAZADA, REPROGRAMADA, CANCELADA, ATENDIDA }
