package com.petcare.controller;

import com.petcare.dto.UsuarioForm;
import com.petcare.model.Rol;
import com.petcare.model.Usuario;
import com.petcare.service.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/config")
public class ConfigController {

    private final UsuarioService service;

    public ConfigController(UsuarioService service) {
        this.service = service;
    }

    @GetMapping("/usuarios")
    public String usuarios(Model model) {
        model.addAttribute("lista", service.listar());
        return "config/usuarios";
    }

    @GetMapping("/usuarios/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("form", new UsuarioForm());
        model.addAttribute("roles", Rol.values());
        return "config/usuario-form";
    }

    @GetMapping("/usuarios/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        Usuario u = service.obtener(id);
        UsuarioForm f = new UsuarioForm();
        f.setId(u.getId());
        f.setNombreUsuario(u.getNombreUsuario());
        f.setRol(u.getRol());
        f.setEstado(u.getEstado());
        model.addAttribute("form", f);
        model.addAttribute("roles", Rol.values());
        return "config/usuario-form";
    }

    @PostMapping("/usuarios/guardar")
    public String guardar(@Valid @ModelAttribute("form") UsuarioForm f, BindingResult br, Model model, RedirectAttributes ra) {
        model.addAttribute("roles", Rol.values());
        if (br.hasErrors()) return "config/usuario-form";
        try {
            service.guardar(f);
        } catch (com.petcare.exception.NegocioException e) {
            br.reject("negocio", e.getMessage());
            return "config/usuario-form";
        }
        ra.addFlashAttribute("ok", "Usuario guardado correctamente.");
        return "redirect:/config/usuarios";
    }

    @PostMapping("/usuarios/eliminar/{id}")
    public String eliminar(@PathVariable Long id, Authentication auth, RedirectAttributes ra) {
        service.eliminar(id, auth.getName());
        ra.addFlashAttribute("ok", "Usuario eliminado.");
        return "redirect:/config/usuarios";
    }

    @GetMapping("/roles")
    public String roles(Model model) {
        Map<Rol, List<Usuario>> grupos = new LinkedHashMap<>();
        for (Rol r : Rol.values()) grupos.put(r, service.porRol(r));
        model.addAttribute("grupos", grupos);
        return "config/roles";
    }
}
