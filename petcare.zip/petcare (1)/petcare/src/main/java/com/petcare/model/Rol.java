package com.petcare.model;

public enum Rol { ADMINISTRADOR, RECEPCIONISTA, VETERINARIO, CLIENTE }
