package com.petcare.service;

import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.petcare.exception.NegocioException;
import com.petcare.model.*;
import com.petcare.repository.*;
import org.springframework.stereotype.Service;
import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

@Service
public class ReporteService {

    private static final DateTimeFormatter F = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final Color AZUL = new Color(0x1F, 0x3A, 0x5F);

    private final ProductoRepository productoRepo;
    private final CitaRepository citaRepo;
    private final MascotaRepository mascotaRepo;
    private final HistorialRepository historialRepo;
    private final DetalleAtencionRepository detalleRepo;

    public ReporteService(ProductoRepository productoRepo, CitaRepository citaRepo, MascotaRepository mascotaRepo, HistorialRepository historialRepo, DetalleAtencionRepository detalleRepo) {
        this.productoRepo = productoRepo;
        this.citaRepo = citaRepo;
        this.mascotaRepo = mascotaRepo;
        this.historialRepo = historialRepo;
        this.detalleRepo = detalleRepo;
    }

    public byte[] inventario() {
        List<String[]> filas = new ArrayList<>();
        for (Producto p : productoRepo.findAllByOrderByNombre()) {
            filas.add(new String[]{p.getNombre(), String.valueOf(p.getStockActual()), String.valueOf(p.getStockMinimo()),
                    String.format("$ %,.0f", p.getPrecioUnitario()),
                    p.getActivo() ? (p.isStockBajo() ? "STOCK BAJO" : "Normal") : "Inactivo"});
        }
        return pdf("Reporte de inventario", new String[]{"Producto", "Stock actual", "Stock mínimo", "Precio unitario", "Estado"}, filas);
    }

    public byte[] stockBajo() {
        List<String[]> filas = new ArrayList<>();
        for (Producto p : productoRepo.findStockBajo()) {
            filas.add(new String[]{p.getNombre(), String.valueOf(p.getStockActual()), String.valueOf(p.getStockMinimo()),
                    String.valueOf(Math.max(0, p.getStockMinimo() - p.getStockActual()))});
        }
        return pdf("Productos con stock bajo", new String[]{"Producto", "Stock actual", "Stock mínimo", "Faltante al mínimo"}, filas);
    }

    public byte[] consumoMensual() {
        Map<String, Integer> acumulado = new TreeMap<>();
        for (DetalleAtencion d : detalleRepo.findAll()) {
            String clave = YearMonth.from(d.getHistorial().getFecha()) + "|" + d.getProducto().getNombre();
            acumulado.merge(clave, d.getCantidadUtilizada(), Integer::sum);
        }
        List<String[]> filas = new ArrayList<>();
        acumulado.forEach((k, total) -> {
            String[] partes = k.split("\\|", 2);
            filas.add(new String[]{partes[0], partes[1], String.valueOf(total)});
        });
        return pdf("Consumo de insumos por mes", new String[]{"Mes", "Producto", "Unidades consumidas"}, filas);
    }

    public byte[] citas() {
        List<String[]> filas = new ArrayList<>();
        for (Cita c : citaRepo.findAllByOrderByFechaDescHoraDesc()) {
            filas.add(new String[]{c.getFecha().format(F), c.getHora().toString(), c.getMascota().getNombre(),
                    c.getPropietario().getNombre(), c.getMotivo(), c.getEstado().name()});
        }
        return pdf("Reporte de citas", new String[]{"Fecha", "Hora", "Mascota", "Propietario", "Motivo", "Estado"}, filas);
    }

    public byte[] pacientes() {
        List<String[]> filas = new ArrayList<>();
        for (Mascota m : mascotaRepo.findAll()) {
            filas.add(new String[]{m.getNombre(), m.getEspecie(), nvl(m.getRaza()),
                    m.getEdad() == null ? "" : String.valueOf(m.getEdad()),
                    m.getPropietario().getNombre(), m.getPropietario().getDocumento(), nvl(m.getPropietario().getTelefono()),
                    Boolean.TRUE.equals(m.getActivo()) ? "Activa" : "Oculta"});
        }
        return pdf("Listado de pacientes y propietarios",
                new String[]{"Mascota", "Especie", "Raza", "Edad", "Propietario", "Documento", "Teléfono", "Estado"}, filas);
    }

    public byte[] historial(Long mascotaId) {
        Mascota m = mascotaRepo.findById(mascotaId).orElseThrow(() -> new NegocioException("La mascota no existe."));
        List<String[]> filas = new ArrayList<>();
        for (HistorialClinico h : historialRepo.findByMascotaOrderByFechaDescIdDesc(m)) {
            StringBuilder ins = new StringBuilder();
            h.getDetalles().forEach(d -> ins.append(d.getProducto().getNombre()).append(" x").append(d.getCantidadUtilizada()).append("; "));
            filas.add(new String[]{h.getFecha().format(F), h.getVeterinario().getNombre(), h.getMotivo(),
                    nvl(h.getDiagnostico()), nvl(h.getTratamiento()), ins.toString()});
        }
        return pdf("Historial clínico de " + m.getNombre() + " (" + m.getPropietario().getNombre() + ")",
                new String[]{"Fecha", "Veterinario", "Motivo", "Diagnóstico", "Tratamiento", "Insumos"}, filas);
    }

    private String nvl(String s) {
        return s == null ? "" : s;
    }

    private byte[] pdf(String titulo, String[] cabecera, List<String[]> filas) {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            Document doc = new Document(PageSize.A4.rotate(), 36, 36, 36, 36);
            PdfWriter.getInstance(doc, out);
            doc.open();

            doc.add(new Paragraph("Veterinaria PetCare", new Font(Font.HELVETICA, 18, Font.BOLD, AZUL)));
            doc.add(new Paragraph(titulo, new Font(Font.HELVETICA, 13, Font.BOLD)));
            doc.add(new Paragraph("Generado: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")),
                    new Font(Font.HELVETICA, 9, Font.ITALIC, Color.GRAY)));
            doc.add(Chunk.NEWLINE);

            PdfPTable tabla = new PdfPTable(cabecera.length);
            tabla.setWidthPercentage(100);
            Font fCab = new Font(Font.HELVETICA, 10, Font.BOLD, Color.WHITE);
            for (String c : cabecera) {
                PdfPCell cell = new PdfPCell(new Phrase(c, fCab));
                cell.setBackgroundColor(AZUL);
                cell.setPadding(5);
                tabla.addCell(cell);
            }
            Font fCel = new Font(Font.HELVETICA, 9);
            for (String[] fila : filas) {
                for (String v : fila) {
                    PdfPCell cell = new PdfPCell(new Phrase(v, fCel));
                    cell.setPadding(4);
                    tabla.addCell(cell);
                }
            }
            if (filas.isEmpty()) {
                PdfPCell vacio = new PdfPCell(new Phrase("Sin registros para mostrar.", fCel));
                vacio.setColspan(cabecera.length);
                vacio.setPadding(8);
                tabla.addCell(vacio);
            }
            doc.add(tabla);
            doc.add(new Paragraph("Total de registros: " + filas.size(), new Font(Font.HELVETICA, 9, Font.BOLD)));
            doc.close();
            return out.toByteArray();
        } catch (DocumentException e) {
            throw new NegocioException("No se pudo generar el PDF: " + e.getMessage());
        }
    }
}
