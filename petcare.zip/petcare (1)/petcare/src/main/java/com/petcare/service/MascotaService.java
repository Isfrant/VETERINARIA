package com.petcare.service;

import com.petcare.exception.NegocioException;
import com.petcare.model.Mascota;
import com.petcare.model.Propietario;
import com.petcare.repository.CitaRepository;
import com.petcare.repository.MascotaRepository;
import com.petcare.repository.PropietarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class MascotaService {

    private final MascotaRepository repo;
    private final PropietarioRepository propietarioRepo;
    private final CitaRepository citaRepo;

    public MascotaService(MascotaRepository repo, PropietarioRepository propietarioRepo, CitaRepository citaRepo) {
        this.repo = repo;
        this.propietarioRepo = propietarioRepo;
        this.citaRepo = citaRepo;
    }

    public List<Mascota> listar(String q) {
        return buscar(q, false);
    }

    public List<Mascota> listarTodas(String q) {
        return buscar(q, true);
    }

    private List<Mascota> buscar(String q, boolean todas) {
        if (q == null || q.isBlank()) {
            return todas ? repo.findAll() : repo.findByActivoTrueOrderByNombre();
        }
        return todas ? repo.buscar(q.trim()) : repo.buscarActivas(q.trim());
    }

    public List<Mascota> porPropietario(Propietario p) {
        return repo.findByPropietarioAndActivoTrueOrderByNombre(p);
    }

    public Mascota obtener(Long id) {
        return repo.findById(id).orElseThrow(() -> new NegocioException("La mascota no existe."));
    }

    @Transactional
    public Mascota guardar(Mascota form) {
        if (form.getPropietario() == null || form.getPropietario().getId() == null) {
            throw new NegocioException("Seleccione el propietario.");
        }
        Propietario dueno = propietarioRepo.findById(form.getPropietario().getId())
                .orElseThrow(() -> new NegocioException("El propietario no existe."));
        return persistir(form, dueno);
    }

    @Transactional
    public Mascota guardarDeCliente(Mascota form, Propietario dueno) {
        if (form.getId() != null) {
            Mascota existente = obtener(form.getId());
            if (!existente.getPropietario().getId().equals(dueno.getId()) || !Boolean.TRUE.equals(existente.getActivo())) {
                throw new NegocioException("Esa mascota no pertenece a su cuenta.");
            }
        }
        return persistir(form, dueno);
    }

    @Transactional
    public void eliminarDeCliente(Long id, Propietario dueno) {
        Mascota m = obtener(id);
        if (!m.getPropietario().getId().equals(dueno.getId()) || !Boolean.TRUE.equals(m.getActivo())) {
            throw new NegocioException("Esa mascota no pertenece a su cuenta.");
        }
        eliminar(id);
    }

    @Transactional
    public void eliminar(Long id) {
        Mascota m = obtener(id);
        citaRepo.deleteByMascota(m);
        m.setActivo(false);
        repo.save(m);
    }

    @Transactional
    public void reactivar(Long id) {
        Mascota m = obtener(id);
        m.setActivo(true);
        repo.save(m);
    }

    private Mascota persistir(Mascota form, Propietario dueno) {
        Mascota m = (form.getId() == null) ? new Mascota() : obtener(form.getId());
        m.setNombre(form.getNombre());
        m.setEspecie(form.getEspecie());
        m.setRaza(form.getRaza());
        m.setEdad(form.getEdad());
        m.setPropietario(dueno);
        return repo.save(m);
    }
}
