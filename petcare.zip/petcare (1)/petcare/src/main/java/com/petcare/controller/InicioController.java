package com.petcare.controller;

import com.petcare.exception.NegocioException;
import com.petcare.model.EstadoCita;
import com.petcare.repository.*;
import com.petcare.service.UsuarioService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class InicioController {

    private final PropietarioRepository propietarioRepo;
    private final MascotaRepository mascotaRepo;
    private final ProductoRepository productoRepo;
    private final CitaRepository citaRepo;
    private final HistorialRepository historialRepo;
    private final UsuarioRepository usuarioRepo;
    private final NotificacionRepository notificacionRepo;
    private final UsuarioService usuarioService;

    public InicioController(PropietarioRepository propietarioRepo, MascotaRepository mascotaRepo, ProductoRepository productoRepo, CitaRepository citaRepo, HistorialRepository historialRepo, UsuarioRepository usuarioRepo, NotificacionRepository notificacionRepo, UsuarioService usuarioService) {
        this.propietarioRepo = propietarioRepo;
        this.mascotaRepo = mascotaRepo;
        this.productoRepo = productoRepo;
        this.citaRepo = citaRepo;
        this.historialRepo = historialRepo;
        this.usuarioRepo = usuarioRepo;
        this.notificacionRepo = notificacionRepo;
        this.usuarioService = usuarioService;
    }

    @GetMapping("/inicio")
    public String inicio(Authentication auth, Model model) {
        model.addAttribute("totalPropietarios", propietarioRepo.count());
        model.addAttribute("totalMascotas", mascotaRepo.countByActivoTrue());
        model.addAttribute("productosBajos", productoRepo.findStockBajo());
        model.addAttribute("citasPendientes", citaRepo.countByEstado(EstadoCita.PENDIENTE));
        model.addAttribute("totalConsultas", historialRepo.count());
        usuarioRepo.findByNombreUsuario(auth.getName()).ifPresent(u ->
                model.addAttribute("notificaciones", notificacionRepo.findTop10ByUsuarioOrderByFechaEnvioDesc(u)));
        return "inicio";
    }

    @GetMapping("/contrasena")
    public String contrasenaForm() {
        return "contrasena";
    }

    @PostMapping("/contrasena")
    public String cambiar(@RequestParam String actual, @RequestParam String nueva,
                          @RequestParam String confirmacion, Authentication auth, RedirectAttributes ra) {
        try {
            usuarioService.cambiarClave(auth.getName(), actual, nueva, confirmacion);
            ra.addFlashAttribute("ok", "Contraseña actualizada correctamente.");
        } catch (NegocioException e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/contrasena";
    }
}
