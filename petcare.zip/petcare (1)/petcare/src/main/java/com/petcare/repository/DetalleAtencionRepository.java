package com.petcare.repository;

import com.petcare.model.DetalleAtencion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DetalleAtencionRepository extends JpaRepository<DetalleAtencion, Long> {
}
