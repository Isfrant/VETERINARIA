package com.petcare.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
public class Propietario {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank(message = "El documento es obligatorio") @Size(max = 20)
    private String documento;
    @NotBlank(message = "El nombre es obligatorio") @Size(max = 100)
    private String nombre;
    @Size(max = 20)
    private String telefono;
    @Email(message = "Correo no válido") @Size(max = 100)
    private String email;
    @OneToOne @JoinColumn(name = "usuario_id")
    private Usuario usuario;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getDocumento() { return documento; }
    public void setDocumento(String documento) { this.documento = documento; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }
}
