package com.petcare.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
public class Mascota {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank(message = "El nombre es obligatorio") @Size(max = 50)
    private String nombre;
    @NotBlank(message = "La especie es obligatoria") @Size(max = 30)
    private String especie;
    @Size(max = 50)
    private String raza;
    @Min(value = 0, message = "La edad no puede ser negativa")
    private Integer edad;
    @Column(nullable = false)
    private Boolean activo = true;
    @ManyToOne(optional = false) @JoinColumn(name = "propietario_id")
    private Propietario propietario;

    public Boolean getActivo() { return activo; }
    public void setActivo(Boolean activo) { this.activo = activo; }
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getEspecie() { return especie; }
    public void setEspecie(String especie) { this.especie = especie; }

    public String getRaza() { return raza; }
    public void setRaza(String raza) { this.raza = raza; }

    public Integer getEdad() { return edad; }
    public void setEdad(Integer edad) { this.edad = edad; }

    public Propietario getPropietario() { return propietario; }
    public void setPropietario(Propietario propietario) { this.propietario = propietario; }
}
