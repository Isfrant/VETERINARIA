package com.petcare.exception;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler({NegocioException.class, DataIntegrityViolationException.class})
    public String manejar(Exception e, HttpServletRequest req, RedirectAttributes ra) {
        String msg = (e instanceof NegocioException)
                ? e.getMessage()
                : "No se pudo completar la operación: el registro tiene datos asociados o está duplicado.";
        ra.addFlashAttribute("error", msg);
        String destino = req.getHeader("Referer");
        return "redirect:" + (destino != null ? destino : "/inicio");
    }
}
