package com.petcare.controller;

import com.petcare.repository.PropietarioRepository;
import com.petcare.repository.VeterinarioRepository;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice
public class GlobalModelAdvice {

    private final PropietarioRepository propietarioRepo;
    private final VeterinarioRepository veterinarioRepo;

    public GlobalModelAdvice(PropietarioRepository propietarioRepo, VeterinarioRepository veterinarioRepo) {
        this.propietarioRepo = propietarioRepo;
        this.veterinarioRepo = veterinarioRepo;
    }

    private boolean autenticado(Authentication a) {
        return a != null && a.isAuthenticated() && !(a instanceof AnonymousAuthenticationToken);
    }

    @ModelAttribute("nombreMostrar")
    public String nombreMostrar(Authentication a) {
        if (!autenticado(a)) return null;
        String u = a.getName();
        return propietarioRepo.findByUsuarioNombreUsuario(u).map(p -> p.getNombre())
                .orElseGet(() -> veterinarioRepo.findByUsuarioNombreUsuario(u).map(v -> v.getNombre()).orElse(u));
    }

    @ModelAttribute("rolActual")
    public String rolActual(Authentication a) {
        if (!autenticado(a) || a.getAuthorities().isEmpty()) return null;
        return a.getAuthorities().iterator().next().getAuthority().replace("ROLE_", "");
    }
}
